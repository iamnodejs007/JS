var app=angular.module('myApp')
.service('myService',myService);


myService.$inject=['$http'];
function myService($http){
    var service=this;
    service.getSer= function(){
        
            return 1;
     
       
    }

}
var app=angular.module('myApp',['ngMessages'])
.controller('myCtrl',myCtrl);

myCtrl.$inject=['$scope']

function myCtrl($scope){
    
    $scope.Emails=[{id: 'choice1'}];
    $scope.Contacts=[{id: 'choice1'}];
    $scope.set=function(x){
        if (x==0)        
        return "mobile"
        else if (x==1)
        return "work"
        else if (x==2)
        return "work"
        else return "other"
    }
    $scope.addNewChoice = function(x) {
        if (x==1){
       
        var newItemNo = $scope.Emails.length+1;
        $scope.Emails.push({'id':'choice'+newItemNo});
        }
        else{
        var newItemNo = $scope.Contacts.length+1;
        $scope.Contacts.push({'id':'choice'+newItemNo});
        }
      };
        
      $scope.removeChoice = function(x) {

        if (x==1){
        if($scope.Emails.length==1){return;}
        var lastItem = $scope.Emails.length-1;
        $scope.Emails.splice(lastItem);
               }
        else{
             if($scope.Contacts.length==1){return;}
            var lastItem = $scope.Contacts.length-1;
            $scope.Contacts.splice(lastItem);

        }
      };
      $scope.submitForm = function(isValid) {

		// check to make sure the form is completely valid
		if (isValid) { 
			alert('our form is amazing');
		}

	};

   
}
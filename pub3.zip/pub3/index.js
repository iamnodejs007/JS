var app=angular.module('myApp',['ui.bootstrap'])
.controller('myCtrl',myCtrl)
.filter('start', function () {
    return function (input, start) {
        if (!input || !input.length) { return; }
        start = +start;
        return input.slice(start);
    };
});

myCtrl.$inject=['$scope','$timeout','myService']

function myCtrl($scope,myService,$filter,$interpolate,filterFilter){



    $scope.customers=[
        {
          "name": "Georgia Cameron",
          "gender": "female",
          "company": "UNDERTAP",
          "email": [
            "georgiacameron@undertap.com",
            "georgiacameron@undertap.com",
            "georgiacameron@undertap.com",
            "georgiacameron@undertap.com",
            "georgiacameron@undertap.com",
            "georgiacameron@undertap.com",
            "georgiacameron@undertap.com"
          ],
          "phone": "+1 (846) 439-2259",
          "tags": [
            "dolore",
            "incididunt",
            "ad",
            "amet",
            "est",
            "do",
            "quis"
          ]
        },
        {
          "name": "Diaz Guzman",
          "gender": "male",
          "company": "QUINEX",
          "email": [
            "diazguzman@quinex.com",
            "diazguzman@quinex.com",
            "diazguzman@quinex.com",
            "diazguzman@quinex.com",
            "diazguzman@quinex.com",
            "diazguzman@quinex.com",
            "diazguzman@quinex.com"
          ],
          "phone": "+1 (857) 478-3148",
          "tags": [
            "sunt",
            "sint",
            "do",
            "esse",
            "mollit",
            "velit",
            "ipsum"
          ]
        },
        {
          "name": "Potts Johnston",
          "gender": "male",
          "company": "COMTRAK",
          "email": [
            "pottsjohnston@comtrak.com",
            "pottsjohnston@comtrak.com",
            "pottsjohnston@comtrak.com",
            "pottsjohnston@comtrak.com",
            "pottsjohnston@comtrak.com",
            "pottsjohnston@comtrak.com",
            "pottsjohnston@comtrak.com"
          ],
          "phone": "+1 (830) 438-2094",
          "tags": [
            "exercitation",
            "ullamco",
            "ullamco",
            "laborum",
            "consequat",
            "ea",
            "non"
          ]
        },
        {
          "name": "Sawyer Todd",
          "gender": "male",
          "company": "BITREX",
          "email": [
            "sawyertodd@bitrex.com",
            "sawyertodd@bitrex.com",
            "sawyertodd@bitrex.com",
            "sawyertodd@bitrex.com",
            "sawyertodd@bitrex.com",
            "sawyertodd@bitrex.com",
            "sawyertodd@bitrex.com"
          ],
          "phone": "+1 (868) 543-3782",
          "tags": [
            "enim",
            "elit",
            "cupidatat",
            "laboris",
            "amet",
            "sint",
            "et"
          ]
        },
        {
          "name": "Best Roman",
          "gender": "male",
          "company": "DATAGENE",
          "email": [
            "bestroman@datagene.com",
            "bestroman@datagene.com",
            "bestroman@datagene.com",
            "bestroman@datagene.com",
            "bestroman@datagene.com",
            "bestroman@datagene.com",
            "bestroman@datagene.com"
          ],
          "phone": "+1 (931) 597-3077",
          "tags": [
            "do",
            "veniam",
            "ea",
            "deserunt",
            "incididunt",
            "dolore",
            "labore"
          ]
        },
        {
          "name": "Slater Wise",
          "gender": "male",
          "company": "COSMETEX",
          "email": [
            "slaterwise@cosmetex.com",
            "slaterwise@cosmetex.com",
            "slaterwise@cosmetex.com",
            "slaterwise@cosmetex.com",
            "slaterwise@cosmetex.com",
            "slaterwise@cosmetex.com",
            "slaterwise@cosmetex.com"
          ],
          "phone": "+1 (912) 447-2824",
          "tags": [
            "mollit",
            "commodo",
            "reprehenderit",
            "irure",
            "et",
            "tempor",
            "officia"
          ]
        }
      ]
  











console.log( $scope.customers[0].name)   
$scope.itemsPerPage = 5;
   
    $scope.currentPage = 1;
    $scope.maxSize = 5;
    list_count = $scope.customers.length;
    $scope.totalItems = list_count;

    $scope.$watch('customers', function() {

  

     
            
        $scope.filterList = filterFilter($scope.customers);
                       
      $scope.itemsPerPage = 5;
      
       $scope.currentPage = 1;
       $scope.maxSize = 5;
       list_count = $scope.customers.length;
       $scope.totalItems = list_count;
                    
                     $scope.currentPage = 1;
                 });
   
   
   
              $scope.$watch('search.$', function (term) {
   
        
                     var obj = { $: term }
                     $scope.filterList=null;
                      $scope.filterList = filterFilter($scope.customers, obj);
                    
                     $scope.currentPage = 1;
                 });
   
     $scope.$watch('search.Person_Name', function (term) {
         
                     var obj = { Person_Name: term }
                     $scope.filterList = filterFilter($scope.customers, obj);
                     $scope.currentPage = 1;
                 });
   
      $scope.$watch('search.Div', function (term) {
                     var obj = { Div: term }
                     $scope.filterList = filterFilter($scope.customers, obj);
                     $scope.currentPage = 1;
                 });


                }
		
   





